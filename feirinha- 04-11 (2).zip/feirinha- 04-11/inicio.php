<?php

include "incs/cabecalho.php";

?>


<div class="container" id="logo">
    <img src="img/nos.png" />
</div>


<div class="galeria ">
    <div class="galeria-item shadow-lg p-3 mb-5 bg-body-tertiary rounded text-center">
        <h5>Conheça nossa feirinha</h5>

        <img src="img/sobre.jpg" style="height: 200px; object-fit: cover" alt="feirinha">

        <br><br>
        <a href="sobrenos.php"><button type="submit" class="btn btn-success roudend col-6">Ver Mais</button></a>


    </div>

    <div class="galeria-item shadow-lg p-3 mb-5 bg-body-tertiary rounded text-center">
        <h5>Nossa Ecobag</h5>

        <img src="img/ecobag.png" style="height: 200px; object-fit: cover" alt="oferta">

        <br>
        <br>
        <a href="ecobag.php"><button type="submit" class="btn btn-success roudend col-6">Ver Mais</button></a>
    </div>
    <div class="galeria-item shadow-lg p-3 mb-5 bg-body-tertiary rounded text-center">
        <h5>Novidade</h5>
        <img src="img/ETF.png" style="height: 200px; object-fit: cover" alt="novidade">
        <br><br>
        <a href="novidade.php"><button type="submit" class="btn btn-success roudend col-6">Ver Mais</button></a>
    </div>
</div>




<footer>
    <p>2024 Feirinha Online</p> <a href="formulario.php">cadastrar produtos</a>
</footer>
</body>

</html>