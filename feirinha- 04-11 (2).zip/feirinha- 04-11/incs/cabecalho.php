<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feirinha Online</title>
    <link rel="icon" href="img/logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/estilos.css">
</head>

<body>

    <header>

        <div class="navbar">


        <div class="logo">
            <img src="img/logo.png">
        </div>
        <ul> 
            <li><a class="rounded-4" href="inicio.php">INÍCIO</a></li>
            <li><a class="rounded-4" href="produtos.php?categoria=1">ENLATADOS</a></li>
            <li><a class="rounded-4" href="produtos.php?categoria=2">COMIDAS DIVERSAS</a></li> 
            <li><a class="rounded-4" href="produtos.php?categoria=3">VEGETAIS</a></li>
            <li><a class="rounded-4" href="produtos.php?categoria=4">ROUPAS</a></li>
            <li><a class="rounded-4" href="produtos.php?categoria=5">ARTESANATO</a></li>
            <li><a class="rounded-4" href="produtos.php?categoria=6">PRODUTOS DE BELEZA</a></li>
            
        </ul>
        </div>
    </header>

    
