<?php

class ConexaoBD
{

    public static function conectar(): PDO
    {
        $conexao = new PDO("mysql:host=127.0.0.1;dbname=feirinha", "root", "Batman");
        return $conexao;
    }
}
