<?php
require_once "ConexaoBD.php";

class CategoriaDAO
{

    public static function listarCategorias($idcategoria)
    {
        $conexao = ConexaoBD::conectar();
        $sql = "select * from categorias";
        $categorias = $conexao->query($sql);
        return $categorias;
    }
}
