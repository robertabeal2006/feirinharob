<?php
require_once "ConexaoBD.php";
require_once "funcoes.php";

class ProdutoDAO
{

    static function cadastrar($dados)
    {
        $nome = $dados['nome'];
        $categoria = $dados['categoria'];
        $preço = $dados['preço'];
        $imagem = pegarImagem($_FILES);

        $conexao = ConexaoBD::conectar();
        $sql = "insert into produtos (nome, categoria, preço, imagem) values ('$nome', '$categoria', '$preço', '$imagem')";
        $conexao->exec($sql);
    }

    static function listar()
    {
        $conexao = ConexaoBD::conectar();
        $sql = "SELECT * FROM produtos";
        $perguntas = $conexao->query($sql);
        return $perguntas->fetchAll(PDO::FETCH_ASSOC);
    }
    static function listarCategoria($categoria)
    {
        $conexao = ConexaoBD::conectar();
        $sql = "SELECT * FROM produtos where categoria=$categoria";
        $perguntas = $conexao->query($sql);
        return $perguntas->fetchAll(PDO::FETCH_ASSOC);
    }
}
