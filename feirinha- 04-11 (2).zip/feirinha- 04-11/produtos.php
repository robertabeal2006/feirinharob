<?php

include "incs/cabecalho.php";

?>




<div class="galeria">
    <div class="g-5 mb-5 bg-body-tertiary rounded text-center row m-auto d-flex justify-content-center">
        <?php
        require_once "src/ProdutoDAO.php";
        $listar = ProdutoDAO::listarCategoria($_GET['categoria']);
        foreach ($listar as $produto) {
        ?>
            <div class="col-3 m-1 p-3 shadow rounded">
                <h5 value="<?= $produto['nome'] ?>"><?= $produto['nome'] ?></h5>
                <img class="rounded-3" src='data:image/jpeg;base64,<?= base64_encode(string: $produto['imagem']) ?>' width="200px" style="height: 200px; object-fit: cover" >
                <h5><?= $produto['preço'] ?></h5>
                <button type="submit" class="btn btn-success">Comprar</button>
            </div>

            

            
        <?php
        }
        ?>

    </div>
</div>







<footer>
    <p>2024 Feirinha Online</p>
</footer>
</body>

</html>