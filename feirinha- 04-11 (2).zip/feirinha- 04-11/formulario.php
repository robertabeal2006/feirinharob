<?php

include "incs/cabecalho.php";

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <title>Cadastro</title>
</head>

<body class="d-flex align-items-center" style="height: 100vh;">
  <form action="cadastro.php" method="POST" enctype="multipart/form-data" class="w-25 container mt-3 border rounded p-3">
    <h4>Cadastro de Produtos</h4>
    <div class="mb-3">
      <label class="form-label">Nome</label>
      <input type="text" class="form-control" name="nome" placeholder="nome">
    </div>
    <div class="mb-3">
      <label class="form-label">Categoria</label>
      <select name="categoria" class="form-select">
        <option value="1">Enlatados</option>
        <option value="2">Comidas Diversas</option>
        <option value="3">Vegetais</option>
        <option value="4">Roupas</option>
        <option value="5">Artesanato</option>
        <option value="6">Produtos de Beleza</option>
      </select>
    </div>
    <div class="mb-3">
      <label class="form-label">Preço</label>
      <input type="text" class="form-control" name="preço" placeholder="R$">
    </div>
    <div class="mb-3">
      <label class="form-label">Foto</label>
      <input type="file" class="form-control" name="imagem" placeholder="imagem">
    </div>
    <button type="submit" class="btn btn-success">Cadastrar</button>

  </form>
</body>

</html>