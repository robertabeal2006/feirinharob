<?php
require_once "src/ProdutoDAO.php";
ProdutoDAO::cadastrar($_POST);
header("location:sucesso.php");